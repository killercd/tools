# -*- coding: utf-8 -*-
{'application': False,
 'author': 'My Company',
 'category': 'Sales',
 'data': ['views/views.xml', 'views/templates.xml', 'views/feltrinelli_report.xml',
          'data/report_paperformat.xml', 'report.xml'],
 'demo': ['demo/demo.xml'],
 'depends': ['sale'],
 'installable': True,
 'license': 'LGPL-3',
 'name': 'feltrinelli_reports',
 'summary': 'Report di stampa Feltrinelli per ordini di vendita',
 'version': '18.0.1.0.0',
 'website': 'http://www.yourcompany.com'}

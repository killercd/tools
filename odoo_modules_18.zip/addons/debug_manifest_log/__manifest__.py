{
    "name": "Debug Manifest Log",
    "summary": "Logga i __manifest__.py letti (modulo, percorso, versione) su file dedicato.",
    "version": "18.0.1.0.0",
    "license": "LGPL-3",
    "installable": True,
    "application": False,
}

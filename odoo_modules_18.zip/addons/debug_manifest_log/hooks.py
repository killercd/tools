# addons/debug_manifest_log/hooks.py
import os, re, sys, logging, importlib, traceback
from logging.handlers import RotatingFileHandler

from odoo.modules import module as mod
from odoo.modules import loading as ld
from odoo.tools import config
from odoo import api, sql_db, SUPERUSER_ID

# --------------------------
# Logger: manifest reads
# --------------------------
_MANIFEST_LOG = logging.getLogger("odoo.manifest_files")
_ALLOWED_VER = re.compile(r'^(?:\d+\.\d+(?:\.\d+)?|18\.0\.\d+\.\d+(?:\.\d+)?)$')

def _setup_manifest_logger():
    if getattr(_setup_manifest_logger, "_inited", False):
        return
    path = os.environ.get("ODOO_MANIFEST_LOG") or "/home/odoo/data/manifest_reads.log"
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        h = RotatingFileHandler(path, maxBytes=2*1024*1024, backupCount=5, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
        h.setLevel(logging.INFO)
        _MANIFEST_LOG.addHandler(h)
        _MANIFEST_LOG.setLevel(logging.INFO)
        _MANIFEST_LOG.propagate = False
        _setup_manifest_logger._inited = True
    except Exception:
        pass

def _startup_snapshot():
    if getattr(_startup_snapshot, "_done", False):
        return
    _startup_snapshot._done = True
    try:
        _setup_manifest_logger()
        apath = (config.get("addons_path") or "").split(",")
        apath = [p.strip() for p in apath if p.strip()]
        _MANIFEST_LOG.info("STARTUP addons_path=%s", apath)
        _MANIFEST_LOG.info("STARTUP sys.path[0:5]=%s ...", sys.path[:5])

        # scansione duplicati e versioni non valide
        seen = {}
        for base in apath:
            if not os.path.isdir(base):
                continue
            for entry in os.listdir(base):
                moddir = os.path.join(base, entry)
                mf = os.path.join(moddir, "__manifest__.py")
                if os.path.isdir(moddir) and os.path.isfile(mf):
                    seen.setdefault(entry, []).append(mf)

        for name, paths in seen.items():
            if len(paths) > 1:
                _MANIFEST_LOG.info("DUPLICATE module=%s count=%d paths=%s", name, len(paths), paths)

        for name, paths in seen.items():
            for mf in paths:
                try:
                    with open(mf, "r", encoding="utf-8") as f:
                        s = f.read()
                    m = re.search(r"['\"]version['\"]\s*:\s*['\"]([^'\"]+)['\"]", s)
                    ver = m.group(1) if m else "?"
                    if not _ALLOWED_VER.match(ver):
                        _MANIFEST_LOG.info("INVALID_VERSION module=%s file=%s version=%s", name, mf, ver)
                except Exception:
                    pass
    except Exception:
        pass

def _safe_get_mod_path(module_name, mod_path):
    if mod_path:
        return mod_path
    try:
        return mod.get_module_path(module_name)
    except Exception:
        return None

# wrap load_manifest: log ogni manifest letto
_ORIG_LOAD_MANIFEST = mod.load_manifest
def _logging_load_manifest(module_name, mod_path=None):
    # evita auto-ricorsione sul nostro stesso modulo
    if module_name == "debug_manifest_log":
        return _ORIG_LOAD_MANIFEST(module_name, mod_path)

    _startup_snapshot()
    try:
        _setup_manifest_logger()
    except Exception:
        pass

    mpath = _safe_get_mod_path(module_name, mod_path)
    manifest_path = os.path.join(mpath, "__manifest__.py") if mpath else "(unknown)"
    ver = "?"
    try:
        if mpath and os.path.exists(manifest_path):
            with open(manifest_path, "r", encoding="utf-8") as f:
                s = f.read()
            m = re.search(r"['\"]version['\"]\s*:\s*['\"]([^'\"]+)['\"]", s)
            if m:
                ver = m.group(1)
    except Exception:
        pass

    try:
        tag = "OK" if _ALLOWED_VER.match(ver) else "INVALID"
        _MANIFEST_LOG.info("%s | %s | version=%s | %s", module_name, manifest_path, ver, tag)
    except Exception:
        pass

    return _ORIG_LOAD_MANIFEST(module_name, mod_path)

mod.load_manifest = _logging_load_manifest

# --------------------------
# Logger: loader/registry
# --------------------------
_LOADER_LOG = logging.getLogger("odoo.loader_probe")

def _setup_loader_logger():
    if getattr(_setup_loader_logger, "_inited", False):
        return
    path = os.environ.get("ODOO_LOADER_LOG") or "/home/odoo/data/loader_probe.log"
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        h = RotatingFileHandler(path, maxBytes=2*1024*1024, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
        h.setLevel(logging.INFO)
        _LOADER_LOG.addHandler(h)
        _LOADER_LOG.setLevel(logging.INFO)
        _LOADER_LOG.propagate = False
        _setup_loader_logger._inited = True
    except Exception:
        pass

# Patch 1: logga gli import falliti dei moduli durante il bootstrap
_ORIG_LOAD_OPEN = mod.load_openerp_module
def _log_load_openerp_module(module_name):
    _setup_loader_logger()
    try:
        _LOADER_LOG.info("IMPORT_START %s", module_name)
        return _ORIG_LOAD_OPEN(module_name)
    except Exception:
        _LOADER_LOG.exception("IMPORT_FAIL %s", module_name)
        raise
mod.load_openerp_module = _log_load_openerp_module

# Patch 2: dopo load_modules, spiega perché certi installed non risultano loaded
_ORIG_LOAD_MODULES = ld.load_modules
def _probe_load_modules(registry, *a, **kw):
    res = _ORIG_LOAD_MODULES(registry, *a, **kw)
    try:
        _setup_loader_logger()
        dbname = registry.db_name
        db = sql_db.db_connect(dbname)
        with db.cursor() as cr:
            env = api.Environment(cr, SUPERUSER_ID, {})
            installed = set(env["ir.module.module"].search([("state","=","installed")]).mapped("name"))
            loaded = set(getattr(registry, "_init_modules", []) or [])
            not_loaded = sorted(installed - loaded)

            _LOADER_LOG.info("BOOTSTRAP SUMMARY db=%s", dbname)
            _LOADER_LOG.info("addons_path=%s", config.get("addons_path"))
            _LOADER_LOG.info("installed=%s", sorted(installed))
            _LOADER_LOG.info("loaded=%s", sorted(loaded))
            _LOADER_LOG.info("NOT_LOADED=%s", not_loaded)

            for mname in not_loaded:
                info = {"module": mname}
                # path e manifest
                try:
                    path = mod.get_module_path(mname)
                    info["path"] = path or "(not in addons_path)"
                    try:
                        mani = mod.get_manifest(mname)
                        info["version"] = mani.get("version")
                        info["depends"] = mani.get("depends")
                        info["ext_deps"] = mani.get("external_dependencies")
                    except Exception as e:
                        info["manifest_error"] = str(e)
                except Exception as e:
                    info["path_error"] = str(e)

                # dipendenze Odoo mancanti
                try:
                    deps = info.get("depends") or []
                    missing_odoo = [d for d in deps if d not in installed]
                    if missing_odoo:
                        info["missing_odoo_depends"] = missing_odoo
                except Exception:
                    pass

                # dipendenze Python esterne
                try:
                    env["ir.module.module"].check_external_dependencies(mname, "installed")
                except Exception as e:
                    info["external_deps_error"] = str(e)

                # import Python del pacchetto
                try:
                    if info.get("path") and info["path"] != "(not in addons_path)":
                        importlib.import_module(f"odoo.addons.{mname}")
                        info["python_import"] = "OK"
                    else:
                        info["python_import"] = "SKIPPED (no path)"
                except Exception as e:
                    info["python_import"] = "ERROR"
                    info["python_import_error"] = "".join(
                        traceback.format_exception_only(type(e), e)
                    ).strip()

                _LOADER_LOG.info("NOT_LOADED_DIAG %s", info)
    except Exception:
        _LOADER_LOG.exception("loader_probe failed")
    return res

ld.load_modules = _probe_load_modules

{
    "name": "mass_editing (compat shim for v18)",
    "summary": "Bridge verso server_action_mass_edit per compatibilità retro.",
    "version": "18.0.1.0.0",
    "license": "LGPL-3",
    "installable": True,
    "application": False,
    "depends": ["server_action_mass_edit"],
}

{
    "name": "Opencloud Massive Tag Update (compat shim)",
    "summary": "Compatibilità per moduli custom: placeholder, nessuna funzionalità reale.",
    "version": "18.0.1.0.0",
    "license": "LGPL-3",
    "installable": True,
    "application": False,
    "depends": [],
    "data": [
        # "data/placeholders.xml",   # vedi più sotto
    ],
}

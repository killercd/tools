# -*- coding: utf-8 -*-
{
    "name": "Odoo Microsoft Office 365 Integration",
    "summary": "Odoo Integration with Microsoft Office365 Apps (Outlook, Calendar, Task, OneDrive, Contacts).",
    "description": """
Synchronization of Odoo with Microsoft Office365 Apps.
Once data is created in Office365 account, it will be reflected in Odoo with a single click.
    """,
    "author": "WoadSoft",
    "website": "https://woadsoft.com/odoo-integration-with-office-365",
    "category": "Productivity",
    "license": "OPL-1",

    
    "version": "18.0.1.0.1",

    
    "depends": ["base", "mail", "crm"],

    # Dati
    "data": [
        "security/ir.model.access.csv",
        "views/views.xml",
        "views/templates.xml",
    ],

    
    "application": False,
    "installable": True,

    
    "images": ["static/description/banner.gif"],

    
}

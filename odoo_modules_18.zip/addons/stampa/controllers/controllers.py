# -*- coding: utf-8 -*-
from odoo import http
from werkzeug.wrappers import Request, Response
import json
from odoo.addons.queue_job.job import Job
import logging
from functools import wraps
import time
import odoo.addons.stampa.cli.contatti.run_import as contact_import
import odoo.addons.stampa.cli.prodotti.run_import as product_import
import pdb
from pprint import pprint
from odoo.http import request

_logger = logging.getLogger(__name__)

def timeit(func):
    @wraps(func)
    def timeit_wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()
        total_time = end_time - start_time
        print(f'Function {func.__name__}{args} {kwargs} Took {total_time:.4f} seconds')
        return result
    return timeit_wrapper
def caricamento_product_secondario():
    product_file = "/tmp/titoli.csv"
            
    _logger.info("Start caricamento titoli emergenza (%s)",product_file);
    ip = product_import.ImportProducts_14()
    ip.run_batch(http.request.env, product_file)

class ModuloStampa(http.Controller):
   
    @http.route('/import/autori/', auth='public')
    def index(self, **kw):
        contact_file = "/tmp/contact.csv"
        
        _logger.info("Start import autori (%s)",contact_file);
        ic = contact_import.ImportAuthors()
        ic.load_partners(contact_file, http.request.env)
        return "OK"
        
    @http.route('/import/product/', auth='public', csrf=False)
    def list(self, **kw):
        product_file = "/tmp/titoli.csv"
        
        _logger.info("Start import product TESTTEST (%s)",product_file);
        ip = product_import.ImportSafe()
        ip.run_batch(http.request.env, product_file)
        return "OK"


    @http.route('/import/collane/', auth='public', csrf=False)
    def import_collane(self, **kw):
        product_file = "/tmp/titoli.csv"
        
        _logger.info("Start import collane TESTTEST (%s)",product_file);
        ip = product_import.ImportCollane()
        ip.run_batch(http.request.env, product_file)
        return "OK"
    @http.route('/createitem/product/', auth='public', csrf=False)
    def createfile_product(self, **post):
        product_file = "/tmp/titoli.csv"
        if post.get('attachment',False):
            name = post.get('attachment').filename      
            file = post.get('attachment')
            attachment = file.read() 
            with open(product_file,'wb') as fw:
                fw.write(attachment)
        return "OK"

    @http.route('/createitem/autori/', auth='public', csrf=False)
    def createfile_autori(self, **post):
        autori_file = "/tmp/contact.csv"
        if post.get('attachment',False):
            name = post.get('attachment').filename      
            file = post.get('attachment')
            attachment = file.read() 
            with open(autori_file,'wb') as fw:
                fw.write(attachment)
        return "OK"



    @http.route('/getfile/log/', auth='public', csrf=False)
    def getlog_product(self, **post):
        #product_file = "/tmp/titoli.csv"
        product_file = "/home/odoo/logs/odoo.log"
        contents = ""
        with open(product_file,'r') as ff:
            contents = ff.read()

        
        return contents
    
    @http.route('/api/align_translation/', type='http', auth='public', cors='*', methods=['GET'])
    def align_translation_table(self, **post):
        

        
        http.request.env.cr.execute("UPDATE ir_translation SET value = src WHERE name = 'product.template,name' AND value <> src")

        # Committa le modifiche al database
        request.env.cr.commit()

        # Committa le modifiche al database
        http.request.env.cr.commit()
        
        return "Translation updated successfully."
    
    @http.route('/api/authors/', type='http', auth='public', cors='*', methods=['GET'])
    def get_all_authors(self,name=None, **kw):
        authors = http.request.env['stampa.person'].sudo().search([("name","ilike","%"+name+"%")])
        
        return request.make_response(
            headers={'Content-Type': 'application/json'},
            data=json.dumps([{
                'id': author.id,
                'name': author.name,
                'category': author.category_id.name,
                'color': author.color,
            } for author in authors])
        )
    
    @http.route('/api/books/', type='http', auth='public', cors='*', methods=['GET'])
    def get_all_books(self,isbn=None, **kw):
        
        books = http.request.env['product.template'].sudo().search([("barcode","=",isbn)])
        
        return request.make_response(
            headers={'Content-Type': 'application/json'},
            data=json.dumps([{
                'id': book.id,
                'name': book.name,
                'isbn': book.barcode,
                'data_magazzino':book.in_magazzino.strftime("%Y-%m-%d") if book.in_magazzino else "",
                'data_uscita': book.data_uscita.strftime("%Y-%m-%d") if book.data_uscita else "",
            } for book in books])
        )



# -*- encoding: utf-8 -*-

from . import person, product
from . import send_book

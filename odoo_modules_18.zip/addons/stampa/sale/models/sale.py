from odoo import fields, models, api, _
from odoo.addons.queue_job.job import Job
from lxml import etree
import time
import logging
from functools import wraps
from odoo.exceptions import UserError
_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = "sale.order"

    urgenza = fields.Boolean("Urgenza")
    nota = fields.Char(size=30, string="Nota")

    firstname = fields.Char(string="Nome")
    lastname = fields.Char(string="Cognome")

    sent = fields.Boolean("Spedito", default=False)
    invio_singolo = fields.Boolean("Invio singolo", default=False)
    session_id = fields.Char("ID Sessione")

    street = fields.Char(string="Indirizzo")
    street2 = fields.Char(string="Presso")
    city = fields.Char(string="Città")
    province = fields.Char(string="Provincia")
    zip_code = fields.Char(string="Cap")
    country = fields.Char(string="Nazione")


    def action_confirm_single(self, order):
        order.action_confirm()


    def action_confirm_shipping(self, order):
        order.sent = True
        pickings = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))

        for picking in pickings:
            if picking.state == 'draft':
                picking.action_confirm()

            picking.action_assign()

            # Se ci sono prenotazioni, copia riserva -> quantity (equivale a "Imposta quantità")
            # NB: su v18 action_set_quantities_to_reservation imposta move.quantity / move_line.quantity
            if any(ml.reserved_uom_qty for ml in picking.move_line_ids):
                picking.action_set_quantities_to_reservation()
            else:
                # Nessuna prenotazione: forza quantità per NON tracciati
                for move in picking.move_ids_without_package:
                    if move.product_uom_qty <= 0:
                        continue
                    if move.product_id.tracking != 'none':
                        raise UserError(_("Il prodotto '%s' richiede lotto/seriale: specificare le righe prima della convalida.")
                                        % move.product_id.display_name)

                    # Se preferisci lavorare sulle move line:
                    if move.move_line_ids:
                        done = sum(move.move_line_ids.mapped('quantity'))
                        remaining = move.product_uom_qty - done
                        if remaining > 0:
                            move.move_line_ids[0].quantity += remaining
                    else:
                        self.env['stock.move.line'].create({
                            'move_id': move.id,
                            'picking_id': picking.id,
                            'product_id': move.product_id.id,
                            'product_uom_id': move.product_uom.id,
                            'location_id': move.location_id.id,
                            'location_dest_id': move.location_dest_id.id,
                            'quantity': move.product_uom_qty,   # <-- qui la differenza
                        })

                    # Oppure, alternativa semplice sul move (commenta il blocco sopra):
                    # move.quantity = move.product_uom_qty
                    # if 'picked' in move._fields:
                    #     move.picked = True

            res = picking.button_validate()
            if isinstance(res, dict):
                model = res.get('res_model')
                res_id = res.get('res_id')
                if model == 'stock.immediate.transfer':
                    self.env[model].browse(res_id).process()
                elif model == 'stock.backorder.confirmation':
                    # usa .process_cancel() se NON vuoi creare il backorder
                    self.env[model].browse(res_id).process()

        return True







    ## OLD VER14
    # def action_confirm_shipping(self, order):
    #     order.sent = True
    #     for picking in order.picking_ids:
    #         picking.action_assign()
    #         for move in picking.move_lines:
    #             move.quantity_done = move.product_uom_qty
    #         picking._action_done()

    ## OLD v14
    # def button_manda_in_spedizione(self):
    #     for order in self:
    #         self.with_delay().action_confirm_single(order)

    #     view = self.env.ref("sh_message.sh_message_wizard")
    #     context = dict(self.env.context)
    #     context["message"] = "Schedulazione conferma ordini creata con successo. Per verificare controllare la lista nel modulo Queue Job"
    #     context["url"] = ""

    #     return {
    #         "name": "Schedulazione conferma ordini",
    #         "type": "ir.actions.act_window",
    #         "view_type": "form",
    #         "view_mode": "form",
    #         "res_model": "sh.message.wizard",
    #         "views": [(view.id, "form")],
    #         "view_id": view.id,
    #         "target": "new",
    #         "context": context,
    #     }

    def button_manda_in_spedizione(self):
        for order in self:
            self.with_delay().action_confirm_single(order)

        self.env.cr.commit()
        # Aspetta 3 secondi per dare tempo al runner
        time.sleep(3)
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def custom_action_procurement_create(self, obj):
        obj.order_line._action_procurement_create()

    
    

    ## OLD VER 14
    # def action_server_validate_picking(self):
    #     for order in self:
    #         self.with_delay().action_confirm_shipping(order)

    #     view = self.env.ref("sh_message.sh_message_wizard")
    #     context = dict(self.env.context)
    #     context["message"] = "Schedulazione spedizione ordini creata con successo. Per verificare controllare la lista nel modulo Queue Job"
    #     context["url"] = ""

    #     return {
    #         "name": "Ordini spediti",
    #         "type": "ir.actions.act_window",
    #         "view_type": "form",
    #         "view_mode": "form",
    #         "res_model": "sh.message.wizard",
    #         "views": [(view.id, "form")],
    #         "view_id": view.id,
    #         "target": "new",
    #         "context": context,
    #     }


    def action_server_validate_picking(self):
        for order in self:
            self.with_delay().action_confirm_shipping(order)
        self.env.cr.commit()
        # Aspetta 3 secondi per dare tempo al runner
        time.sleep(3)
        return {'type': 'ir.actions.client', 'tag': 'reload'}



class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    message_needaction = fields.Boolean(related="order_id.message_needaction")

    name_order = fields.Char(related="order_id.name", string="Spedizione")
    date_order = fields.Datetime(related="order_id.date_order", store=True)
    partner_id = fields.Many2one(related="order_id.partner_id", store=True, string="Contatto")

    isbn = fields.Char(related="product_id.barcode")

    dedica = fields.Boolean("Dedica")
    urgenza = fields.Boolean(related="order_id.urgenza")  # store=True)
    anticipo = fields.Boolean("Anticipo")

    order_data_uscita = fields.Date(
        related="product_id.product_tmpl_id.data_uscita"
    )
    order_in_magazzino = fields.Date(
        related="product_id.in_magazzino", store=True
    )
    firstname = fields.Char(related="order_id.firstname")
    lastname = fields.Char(related="order_id.lastname")
    autori_id = fields.Many2many(related="product_id.autori_id")
    tag_ids = fields.Many2many(related="order_id.tag_ids")

    address = fields.Char(string="Indirizzo", compute="_get_address")
    test = fields.Char(string="test", compute="_get_address")
    stato=fields.Char(string="Stato Ordine",compute="_get_stato")

    @api.depends("order_id")
    def _get_address(self):

        for record in self:
            record.address = ", ".join(
                filter(
                    None,
                    [
                        record.order_id.street,
                        record.order_id.street2,
                        " ".join(
                            filter(
                                None,
                                [
                                    record.order_id.zip_code,
                                    record.order_id.city,
                                    record.order_id.province,
                                ],
                            )
                        ),
                        record.order_id.country,
                    ],
                )
            )
            
    def _get_stato(self):
        for record in self:
            record.stato=""
            if record.state.strip().lower()=="draft":
                record.stato="In Lavorazione"
            elif record.state.strip().lower()=="sale" and record.order_id.sent:
                record.stato="Spedito"
            elif record.state.strip().lower()=="sale" and not record.order_id.sent:
                record.stato="In Spedizione"

    

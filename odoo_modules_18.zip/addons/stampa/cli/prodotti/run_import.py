from __future__ import print_function
from ast import While  # (non usata, ma lasciata come nell'originale)

import logging
import argparse
from itertools import islice, chain
import csv
import pdb
import unicodedata
import re
from contextlib import contextmanager
from datetime import datetime
import time

import attr
from builtins import str

from odoo.cli import Command
from odoo.addons.stampa.cli.run import environmentContextManager
from odoo.addons.stampa.product.models import *


logger = logging.getLogger(__name__)

BATCH = 10
ENC = "utf-8"
COLLANE_COLOR = 7
DELIMITER = ";"


class LoadingException(Exception):
    pass


@contextmanager
def cursor(env):
    try:
        yield env.cr
    finally:
        env.cr.close()


def slugify(value):
    # Python 3 safe
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    # rimuove accenti mantenendo ascii "pulito"
    value = unicodedata.normalize("NFKD", value)
    value = "".join(c for c in value if not unicodedata.combining(c))
    value = re.sub(r"[^/\w\s@-]", "", value).strip().lower()
    return re.sub(r"[-\s/]+", "_", value)


def external_id(target, field):
    key = slugify(field)
    ext_id = "feltricrm.%s_%s" % (target, key)
    return ext_id


def result_generator(cursor, recordnum=BATCH):
    while True:
        result = cursor.fetchmany(recordnum)
        if not result:
            break
        yield result


def batch_generator(iterable, recordnum=BATCH):
    source = iter(iterable)
    while True:
        batchiter = islice(source, recordnum)
        first = next(batchiter, None)
        if first is None:
            break
        yield list(chain([first], batchiter))


def utf_reader(infile):
    reader = csv.reader(infile, delimiter=DELIMITER)
    for row in reader:
        # infile è testo (aperto con encoding utf-8); normalizziamo comunque a str
        yield [str(cell) for cell in row]

def map_product_type(v):
    if not v:
        return "Goods"
    v = str(v).strip().lower()
    if v in {"product", "storable", "goods", "beni", "prodotto", "physical"}:
        return "Goods"
    if v in {"service", "servizio"}:
        return "Service"
    if v in {"combo", "bundle", "kit", "combinato"}:
        return "Combo"
    return "Goods"

@attr.s
class Product(object):
    name = attr.ib()
    id = attr.ib()
    barcode = attr.ib()
    data_uscita = attr.ib()
    data_cedola = attr.ib()
    nome_cedola = attr.ib()
    redazione = attr.ib()
    collana_id = attr.ib()
    marchio_editoriale = attr.ib(default=None)
    book_type = attr.ib(default=None)
    in_magazzino = attr.ib(default=None)
    autori_id = attr.ib(default=None)
    curatori_id = attr.ib(default=None)
    prefatori_id = attr.ib(default=None)
    traduttori_id = attr.ib(default=None)
    illustratori_id = attr.ib(default=None)
    #type = attr.ib(default="product")
    type = attr.ib(default="Goods") 
    sale_ok = attr.ib(default="true")
    purchase_ok = attr.ib(default="true")


@attr.s
class Category(object):
    name = attr.ib()
    id = attr.ib()
    color = attr.ib(default=None)
    parent_id = attr.ib(default=None)


@attr.s
class Collana(object):
    name = attr.ib()
    id = attr.ib()


class ImportProducts(Command):
    def manage_args(self, args):
        parser = argparse.ArgumentParser()
        parser.add_argument("--debug", action="store_true")
        parser.add_argument("--categories", action="store_true")
        parser.add_argument("--collane")
        parser.add_argument("--filename")
        parser.add_argument("--lanci")
        args, unknown = parser.parse_known_args(args)
        return args, unknown

    def set_ids_check_results(self, results):
        self.errors = results.get("messages")
        self.ids = results.get("ids") or []
        if self.errors:
            logger.error("Errore: %s", self.errors)
            self.rollback()
        else:
            self.commit()
        return self.ids

    def rollback(self):
        self.env.cr.rollback()

    def commit(self):
        self.env.cr.commit()

    def get_category_names(self, field):
        names = [x.strip().title() for x in field.split(";")]
        return [n for n in names if n]

    def get_collane(self, infile):
        reader = utf_reader(infile)
        found = set()
        logger.debug(" get_collane ")
        for line in reader:
            collana_id = line[4].strip()
            collana = line[5].strip()

            if not collana or collana in found:
                continue

            if collana:
                found.add(collana_id)

            yield Collana(
                name=collana,
                id=external_id("collane", collana_id),
            )

    def get_external_ids(self, prefix, values):
        logger.debug("get_external_ids")
        categories = self.get_category_names(values)
        logger.debug("categories: %s", categories)
        if not categories:
            return None
        cat_ids = [external_id(prefix, cat) for cat in categories]
        logger.debug("cat_ids: %s", cat_ids)
        category_id = ",".join(cat_ids)
        logger.debug("category_id: %s", category_id)
        return category_id

    def get_products(self, infile):
        reader = utf_reader(infile)
        next(reader)  # skip first line
        for line in reader:
            isbn13 = line[1]
            titolo = line[2].strip()
            collana_id = line[4].strip()
            collana = line[5].strip()
            data_uscita = line[6]
            in_magazzino = line[7]
            tipo = line[8].title()
            redazione = line[9]
            marchio = line[10].strip().title()
            autori = line[11]
            curatori = line[12]
            prefatori = line[13]
            traduttori = line[14]
            illustratori = line[15]
            nome_cedola = line[16]
            data_cedola = line[17]
            id = external_id("libri", isbn13)

            collana_id = self.get_external_ids("collane", collana_id)
            autori_id = self.get_external_ids("autori", autori)
            curatori_id = self.get_external_ids("autori", curatori)
            prefatori_id = self.get_external_ids("autori", prefatori)
            traduttori_id = self.get_external_ids("autori", traduttori)
            illustratori_id = self.get_external_ids("autori", illustratori)
            product = Product(
                name=titolo,
                id=id,
                barcode=isbn13,
                data_uscita=data_uscita,
                redazione=redazione,
                marchio_editoriale=marchio,
                book_type=tipo,
                in_magazzino=in_magazzino,
                collana_id=collana_id,
                autori_id=autori_id,
                curatori_id=curatori_id,
                prefatori_id=prefatori_id,
                traduttori_id=traduttori_id,
                illustratori_id=illustratori_id,
                data_cedola=data_cedola,
                nome_cedola=nome_cedola,
                type=map_product_type(None),
            )
            yield product

    def adjusted_fields(self, cls):
        fields = [f.name for f in attr.fields(cls)]
        logger.info("fields: %s", fields)
        return [f + "/id" if f.endswith("_id") else f for f in fields]

    def load_collane(self, infile):
        fields = self.adjusted_fields(Collana)
        try:
            categorie_collane = self.get_collane(infile)
            for categoria in categorie_collane:
                values = [attr.astuple(categoria)]
                logger.info("Values: %s", values)
                results = self.env["stampa.collana"].load(fields, values)
                ids = self.set_ids_check_results(results)
                logger.info("ids: %s", ids)
        except Exception:
            logger.exception("caricamento fallito")

    def load_products(self, infile):
        count = 0
        fields = self.adjusted_fields(Product)
        logger.debug("Fields: %s", fields)
        try:
            products = self.get_products(infile)
            for product in products:
                values = [attr.astuple(product)]
                logger.info("Values: %s", values)
                results = self.env["product.template"].load(fields, values)
                ids = self.set_ids_check_results(results)
                count += len(ids)
        except Exception:
            logger.exception("caricamento fallito")

    def _create_sale_order(self, partner, titolo, row):
        vals = {
            "partner_id": partner.id,
            "state": "sale",
            "sent": True,
            "create_ddt": True,
            "urgenza": True if row[26].strip() == "Sì" else False,
            "invio_singolo": False,
            "date_order": datetime.strptime(row[27], "%m/%d/%Y") or False,
            "confirmation_date": datetime.strptime(row[27], "%m/%d/%Y") or False,
            "order_line": [
                (
                    0,
                    0,
                    {
                        "name": titolo.name,
                        "product_id": titolo.id,
                        "product_uom_qty": int(row[6]),
                        "product_uom": titolo.uom_id.id,
                        "price_unit": titolo.list_price,
                    },
                )
            ],
        }

        so = False
        try:
            so = self.env["sale.order"].create(vals)
        except Exception:
            logger.exception(vals)

        return so

    def _get_product_by_isbn(self, isbn):
        titolo = False
        product_template_obj = self.env["product.product"]
        if isbn:
            titolo_id = product_template_obj.search([("barcode", "=", isbn)], limit=1).id
            if titolo_id:
                titolo = product_template_obj.browse(titolo_id)
        return titolo

    def _get_partner_by_codice_critico(self, codice_critico):
        partner = False
        res_partner_obj = self.env["res.partner"]
        if codice_critico:
            partner_id = res_partner_obj.search(
                [("codice_critico", "=", codice_critico)], limit=1
            ).id
            if partner_id:
                partner = res_partner_obj.browse(partner_id)
        return partner

    def _importa_lanci(self, filename):
        reader = csv.reader(filename, delimiter=";")
        next(reader)  # titoli colonne

        countrow = 0
        for row in reader:
            countrow += 1

            if (countrow % 10) == 0:
                self.env.cr.commit()
                logger.info("[{}] righe committate su database".format(countrow))

            codice_critico = row[1]

            if codice_critico in self.DUPLICATED:
                logger.warning(
                    "Trovato critico vecchio [{}] da sostituire con [{}]".format(
                        codice_critico, self.DUPLICATED[codice_critico]
                    )
                )
                codice_critico = self.DUPLICATED[codice_critico]

            partner = self._get_partner_by_codice_critico(codice_critico)
            if not partner:
                logger.error(
                    "Partner con codice critico [{}] non trovato".format(
                        codice_critico
                    )
                )
                continue

            # cerco il titolo
            isbn = row[3]
            titolo = self._get_product_by_isbn(isbn)
            if not titolo:
                logger.error(
                    "Titolo non trovato con isbn [{}] non trovato".format(isbn)
                )
                continue

            so = self._create_sale_order(partner, titolo, row)
            if so:
                for picking in so.picking_ids:
                    picking.action_cancel()

        self.env.cr.commit()

    DUPLICATED = {
        "98420": "102466",
        "96720": "102788",
        "76825": "93546",
        "63507": "102439",
        "75841": "93917",
        "59084": "103318",
        "58431": "93950",
        "61965": "90504",
        "90239": "103082",
        "70918": "94175",
        "64512": "102804",
        "59589": "94030",
        "67970": "97758",
        "65945": "88810",
        "58312": "99513",
        "101025": "103714",
        "62642": "70307",
        "75728": "103140",
        "71439": "102917",
        "60114": "98059",
        "97039": "99950",
        "60387": "89276",
        "98126": "98800",
        "1485": "73241",
        "1537": "59639",
        "72942": "102238",
        "72290": "94955",
        "92847": "103549",
        "57146": "98504",
        "76587": "89590",
        "71773": "94736",
        "76853": "98766",
        "73825": "103306",
        "91009": "102798",
        "61344": "99348",
        "70821": "99483",
        "98738": "103313",
        "64148": "102644",
        "75280": "100952",
        "57972": "101307",
        "1405": "73958",
        "71913": "94119",
        "98655": "102824",
        "99518": "103312",
        "76346": "102726",
        "61879": "103560",
        "96430": "103083",
        "61321": "72765",
        "73887": "101069",
        "103203": "103204",
        "58426": "103204",
        "95799": "103551",
        "73927": "87782",
        "70553": "99918",
        "76191": "94430",
        "102014": "102067",
        "65272": "103773",
        "71781": "101499",
        "59696": "103602",
        "77579": "93547",
        "60645": "93361",
        "60867": "101874",
        "66788": "102919",
        "73728": "98832",
        "77447": "103177",
        "102420": "103219",
        "74945": "94122",
        "72178": "102796",
        "57044": "99262",
        "94296": "95247",
        "63954": "103261",
        "90426": "103544",
        "61549": "91935",
        "91098": "103412",
        "74632": "102653",
        "65885": "102577",
        "74885": "103352",
        "57502": "103215",
        "75234": "101617",
        "95254": "100168",
        "57771": "96849",
        "57259": "93870",
        "94053": "103086",
        "58447": "103086",
        "98065": "102397",
        "3364": "73370",
        "75716": "99928",
        "98371": "101515",
        "67887": "102710",
        "99234": "101942",
        "75775": "98312",
        "98586": "103278",
        "74057": "103278",
        "92608": "102734",
        "58052": "91990",
        "77171": "101445",
        "94512": "103576",
        "74060": "94566",
        "78631": "98704",
        "94353": "103267",
        "77122": "100676",
        "68105": "92922",
        "94340": "97851",
        "99408": "103266",
        "70495": "103266",
        "98044": "103661",
        "71358": "96782",
        "61534": "103490",
        "64113": "103217",
        "62845": "93820",
        "61261": "78823",
        "92220": "98243",
        "66597": "93499",
        "98593": "103580",
        "74811": "88938",
        "76477": "94673",
        "94922": "103563",
        "93288": "101866",
        "63867": "72243",
        "58715": "72243",
        "75516": "92747",
        "57060": "64111",
        "58204": "102144",
        "101572": "103772",
        "74946": "98362",
        "59273": "93374",
        "97108": "100965",
        "57241": "101873",
        "88760": "90775",
        "76574": "93899",
        "65901": "103391",
        "98513": "103106",
        "67975": "103106",
        "95506": "100991",
        "62515": "103459",
        "57635": "102467",
        "94178": "101520",
        "67856": "94092",
        "76693": "90402",
        "59274": "103725",
        "57262": "93834",
        "79302": "102797",
        "98222": "100119",
        "89052": "94511",
        "74449": "94162",
        "97807": "101502",
        "68009": "100172",
        "96459": "103113",
        "99723": "103168",
        "93137": "103793",
        "64160": "103793",
        "58265": "81884",
        "76406": "103786",
        "67381": "96464",
        "99344": "103359",
        "58483": "103676",
        "103304": "103656",
        "65028": "103656",
        "103068": "103202",
        "57623": "103202",
        "77808": "88632",
        "57101": "103603",
        "74662": "102614",
        "71427": "103767",
        "99222": "100958",
        "96581": "103376",
        "96711": "102772",
        "96795": "103042",
    }

    @environmentContextManager(manage_args_method="manage_args")
    def run(self, args, env):
        self.run_batch(args, env)

    def run_batch(self, args, env, fln_name=None):
        logger.info("Start")
        self.env = env
        with cursor(env):
            if args.categories:
                if args.collane:
                    with open(args.collane, "rt", encoding="utf-8", newline="") as filename:
                        self.load_collane(filename)
            else:
                file_open = fln_name if fln_name else args.filename

                if file_open:
                    with open(file_open, "rt", encoding="utf-8", newline="") as filename:
                        self.load_products(filename)

                if args.lanci:
                    logger.info("job import lanci: START")
                    start_time = time.time()

                    with open(args.lanci, "rt", encoding="utf-8", newline="") as filename:
                        self._importa_lanci(filename)

                    logger.info(
                        "job import lanci: ENDED in %s seconds ---"
                        % (time.time() - start_time)
                    )
        logger.info("End")


class ImportProducts_14(ImportProducts):
    def run_batch(self, env, fln_name=None):
        self.env = env
        with cursor(env):
            with open(fln_name, "rt", encoding="utf-8", newline="") as filename:
                self.load_products(filename)
        logger.info("End")

    def load_products(self, infile):
        self.get_products(infile)

    def get_products(self, infile):
        reader = self.utf_reader(infile)
        next(reader)  # skip first line
        try:
            while True:
                line = next(reader)
                isbn13 = line[1]
                titolo = line[2].strip()
                collana_id = line[4].strip()
                collana = line[5].strip()
                data_uscita = line[6]
                in_magazzino = line[7]
                tipo = line[8].title()
                redazione = line[9]
                marchio = line[10].strip().title()
                autori = line[11]
                curatori = line[12]
                prefatori = line[13]
                traduttori = line[14]
                illustratori = line[15]
                nome_cedola = line[16]
                data_cedola = line[17]
                id = self.external_id("libri", isbn13)

                collana_id = self.get_external_ids("collane", collana_id)
                autori_id = self.get_external_ids("autori", autori)
                curatori_id = self.get_external_ids("autori", curatori)
                prefatori_id = self.get_external_ids("autori", prefatori)
                traduttori_id = self.get_external_ids("autori", traduttori)
                illustratori_id = self.get_external_ids("autori", illustratori)
                product = Product(
                    name=titolo,
                    id=id,
                    barcode=isbn13,
                    data_uscita=data_uscita,
                    redazione=redazione,
                    marchio_editoriale=marchio,
                    book_type=tipo,
                    in_magazzino=in_magazzino,
                    collana_id=collana_id,
                    autori_id=autori_id,
                    curatori_id=curatori_id,
                    prefatori_id=prefatori_id,
                    traduttori_id=traduttori_id,
                    illustratori_id=illustratori_id,
                    data_cedola=data_cedola,
                    nome_cedola=nome_cedola,
                )
                self.load_product(product)
        except StopIteration:
            print("FINE")
        except Exception:
            print("ERRORE")

    def load_product(self, product):
        fields = self.adjusted_fields(Product)
        logger.debug("Fields: %s", fields)
        values = [attr.astuple(product)]
        logger.info("Values: %s", values)

        results = self.env["product.template"].sudo().load(fields, values)
        ids = self.set_ids_check_results(results)
        if len(ids) == 0:
            self.env["ir.logging"].sudo().create(
                {
                    "name": "Load product failed",
                    "type": "server",
                    "level": "ERROR",
                    "message": "Load product failed: values: {} message: {}".format(
                        values, results.get("messages")
                    ),
                    "func": "load_product",
                    "path": "load_product",
                    "line": "load_product",
                }
            )

        logger.debug("ids: %s", ids)

    @staticmethod
    def utf_reader(infile):
        reader = csv.reader(infile, delimiter=DELIMITER)
        for row in reader:
            yield [str(cell) for cell in row]

    # Ri-espongo external_id come metodo d'istanza usando la funzione globale
    def external_id(self, target, field):
        return external_id(target, field)


class ImportCollane(ImportProducts_14):
    def run_batch(self, env, fln_name=None):
        self.env = env
        with cursor(env):
            with open(fln_name, "rt", encoding="utf-8", newline="") as filename:
                self.load_collane(filename)
        logger.info("End")

    def get_collane(self, infile):
        reader = self.utf_reader(infile)
        found = set()
        logger.debug(" get_collane ")
        for line in reader:
            collana_id = line[4].strip()
            collana = line[5].strip()

            if not collana or collana in found:
                continue

            if collana:
                found.add(collana_id)

            yield Collana(
                name=collana,
                id=self.external_id("collane", collana_id),
            )

    def load_collane(self, infile):
        # nel caso collane bastano name e id
        try:
            categorie_collane = self.get_collane(infile)
            for categoria in categorie_collane:
                values = [attr.astuple(categoria)]
                logger.info("Values: %s", values)
                results = self.env["stampa.collana"].sudo().load(("name", "id"), values)
                ids = self.set_ids_check_results(results)
                logger.info("ids: %s", ids)
        except Exception:
            logger.exception("caricamento fallito")


class ImportSafe(ImportProducts_14):
    def load_product(self, product):
        super().load_product(product)

* Alexis de Lattre <alexis.delattre@akretion.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Dave Lasley <dave@laslabs.com>
* Jordi Ballester <jordi.ballester@forgeflow.com>
* Franco Tampieri <franco@tampieri.info>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
* Manuel Regidor <manuel.regidor@sygel.es>

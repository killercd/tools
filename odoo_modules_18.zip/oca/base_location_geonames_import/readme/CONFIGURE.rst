To access the menu to import city zip entries from Geonames
you must be part of the group *Administration / Settings*.

If you want/need to modify the default Geonames URL
(http://download.geonames.org/export/zip/), you can set the *geonames.url*
system parameter.

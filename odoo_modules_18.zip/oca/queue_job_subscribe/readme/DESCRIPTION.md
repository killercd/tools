This module allows users to be member of group Job Queue Manager without becoming follower of failed jobs.
This can avoid for some users to receive a lot of emails in case of failing jobs.

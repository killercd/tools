On the user configuration form, there is new Job Notifications checkbox.

If checked, the user becomes follower of failed jobs if he/she is part of the Job Queue Manager group.

If not checked, the user does not become follower of failed jobs.

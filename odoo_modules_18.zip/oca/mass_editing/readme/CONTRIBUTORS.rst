* Oihane Crucelaegui <oihanecrucelaegi@gmail.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Jay Vora <jay.vora@serpentcs.com>
* Juan Negrete <jnegrete@casasalce.com>
* Raul Martin <raul.martin@braintec-group.com>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Iván Todorovich <ivan.todorovich@gmail.com>

* `Tecnativa <https://www.tecnativa.com>`_

  * Jairo Llopis
  * Víctor Martínez
* Tatiana Deribina <tatiana.deribina@spritnit.fi>
* Hieu, Vo Minh Bao <hieu.vmb@komit-consulting.com>

from . import base_config_settings
from . import res_partner
from . import res_users

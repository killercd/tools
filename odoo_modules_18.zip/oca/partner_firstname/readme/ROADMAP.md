Patterns for the inverse function are configurable only at system level.
Maybe this configuration could depend on partner language, country or
company, as discussed at [this OCA
issue](https://github.com/OCA/partner-contact/issues/210)

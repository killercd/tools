* Nicolas Bessi (Camptocamp)
* Ignacio Ibeas (Acysos S.L.)
* Pedro M. Baeza <pedro.baeza@gmail.com>
* Alejandro Santana <alejandrosantana@anubia.es>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>
* Dave Lasley <dave@laslabs.com>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>

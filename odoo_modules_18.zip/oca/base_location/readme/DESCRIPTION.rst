This module introduces a zip model that allows you to manage locations in a better way.

The zips will allow the users to complete automatically all address-related fields by just filling the zip.

Also allows different search filters.

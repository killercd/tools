This module extends the functionality of queue_job and allows to run an Odoo
cron as a queue job.

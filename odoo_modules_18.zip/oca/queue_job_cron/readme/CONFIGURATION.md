To configure this module, you need to:

#. Nothing special to do.
